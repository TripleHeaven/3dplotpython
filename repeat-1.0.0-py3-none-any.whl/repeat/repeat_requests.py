#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Модуль взаимодейтсвия с REPEAT по WEB API
"""
import requests
from requests.exceptions import HTTPError
from .errors import handle_solver_error_codes, REPEATParameterNotExistError
from .data_structures import Parameter, prepare_results
from .repeat_connection import APIKeyAuth


def make_request(parameter : Parameter, auth : APIKeyAuth, solver) -> dict:
  """
  Функция выполнения POST запроса в ядро REPEAT для получения временного ряда
  заданного параметра, переданного в функцию в виде словаря, готового для 
  выполнения запроса модулем requests

  Parameters
  ----------
  parameter : Parameter
    Экземпляр параметра, создаваемый классом Parameter.
  auth : APIKeyAuth
    Экземпляр класса aвторизации для запросов модулем requests
  solver : Solver
    Экземпляр класса Solver с описанием настроек соединения с расчётным модулем 
    REPEAT

  Raises
  ------
  REPEATHTTPError
    Ошибка, объявляемая в случае возникновения проблем при взаимодействии с
    ядром REPEAT:
      - 406 - Not Acceptable. Проверьте правильность имени параметра varName,
      или Parameter.name. Актуальное имя параметра дотсупно через функцию 
      get_model_info.
      
      - 410 - Gone - Попробуйте перезапустить расчёт

  Returns
  -------
  dict
    Словарь с результатами, в котором для ключа dataValues содержится список со
    значениями параметра, а для ключа dataTimes содержится список  
    соответствующих значений времени между timeStart и timeEnd.
  """
  try:
    response = requests.post(
      solver.get_range, 
      auth = auth,
      verify = False,
      json = parameter.to_repeat(),
      headers = solver.to_header_request(),
      )
    response.raise_for_status()
    
  except HTTPError as http_error:
    handle_solver_error_codes(http_error, parameter)
    
  else:
    return response.json()

def check_results(parameter : Parameter, data : dict):
  if not data['dataValues']:
    raise REPEATParameterNotExistError(
      f"Параметр {parameter.name} отсутствует в модели REPEAT\n"
      "Проверьте, пожалуйста, имя параметра"
      )

def get_results(parameter : Parameter, auth : APIKeyAuth, solver):
  """
  Функция возвращает временной ряд значений заданного параметра

  Parameters
  ----------
  parameter : Parameter
    Экземпляр параметра, создаваемый классом Parameter.
  auth : APIKeyAuth
    Экземпляр класса aвторизации для запросов модулем requests
  solver : Solver
    Экземпляр класса Solver с описанием настроек соединения с расчётным модулем 
    REPEAT
    
  Raises
  ------
  REPEATHTTPError
    Ошибка, объявляемая в случае возникновения проблем при взаимодействии с
    ядром REPEAT:
      - 406 - Not Acceptable. Проверьте правильность имени параметра varName,
      или Parameter.name. Актуальное имя параметра дотсупно через функцию 
      get_model_info.
      
      - 410 - Gone - Попробуйте перезапустить расчёт

  Returns
  -------
  pandas.Series
    Временной ряд значений параметра со следующими атрибутами:
      - index содержит значения времени в интервале времени между start и end
      для экземпляра класса TimeInterval, который требуется при 
      создании нового параметра
      
      - values содержит значения параметра для заданного интервала времени
      
      - name содержит имя параметра, соответствующее атрибуту parameter.name
 
  Examples
  --------
  >>> t_interval = TimeInterval(2000, 2050)
  >>> param = Parameter("1687722637724_OUT_3", t_interval)
  >>> results = get_results(param)
  >>> print(results.head(3))
  2000.0    322.78870
  2001.0    285.93127
  2002.0    221.03392
  Name: 1687722637724_OUT_3, dtype: float64

  """
  data = make_request(parameter, auth, solver)
  check_results(parameter, data)
  return prepare_results(parameter, data)

