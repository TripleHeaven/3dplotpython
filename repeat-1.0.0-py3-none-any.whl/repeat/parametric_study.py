#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

.. versionadded:: 1.0.0

Модуль пакета repeat предназначен для подготовки значений глобальных переменных 
модели REPEAT с целью выполнения параметрических исследований.

Применение модуля ``parametric_study`` пакета repeat позволяет выполнять
параметрические исследования, снижая трудоёмкость подготовки Python программ, 
поскольку инженеру не потребуется использовать вложенные циклы в случае 
перебора значений при любом количестве глобальных переменных.

Данный модуль содержит основные функции подготовки значений переменных:
  
#. ``get_cartesian_product`` - Функция подготовки набора значений глобальных 
   переменных по методу **декартова произведения** с целью получения 
   результатов расчёта модели REPEAT на сетке значений глобальных переменных;
#. ``get_latin_hypercube`` - Функция подготовки разреженного набора значений 
   глобальных переменных по методу **латинского гиперкуба** для вычислительно 
   затратных случаев параметрических исследований.

"""
from typing import Union
import numpy as np
import pandas as pd
from scipy.stats import qmc
import repeat.errors as err
import repeat.repeat_model as rm
import repeat.validators as vld


def _make_cartesian_product(variables : dict[str, pd.Series]):
  
  grid = [i.flatten() for i in np.meshgrid(*variables.values())]
  design = pd.DataFrame(dict(zip(variables.keys(), grid)), dtype = float)
  
  return design


def get_cartesian_product(model : rm.ExplorationModel,
                          variable_values : dict[str, Union[pd.Series, np.ndarray]]
                          ) -> pd.DataFrame:
  """
  Функция возвращает декартово произведение для множества значений глобальных 
  переменных с целью выполнения параметрических исследований модели REPEAT.
  
  Например, для случая двух переменных ``diameter = np.array([0.05, 0.1])``
  и ``pressure = np.array([1e4, 2e4])`` функция вернёт таблицу pandas DataFrame
  следующего вида.
  
  =  ========  ========
     diameter  pressure
  =  ========  ========
  0      0.05   10000.0
  1      0.10   10000.0
  2      0.05   20000.0
  3      0.10   20000.0
  =  ========  ========
  
  Алгоритм формирует набор расчётных случаев с количеством, равным произведению
  длин векторов значений всех глобальных переменных, указанных аргументу
  ``variable_values``. Для примера, приведённого выше, длина вектора значений
  ``diameter = 2`` и длина вектора ``pressure = 2``. Соответственно алгоритм
  подготовит набор, включающий 4 расчётных случая для выполнения 4 
  параметрических исследований модели REPEAT.
  
  Parameters
  ----------
  model : rm.ExplorationModel
    Экземпляр класса ExplorationModel.
  variable_values : dict[str, pd.Series | np.ndarray]
    Словарь с наборами значений глобальных переменных. Ключами словаря должны 
    быть строковые значения имён глобальных переменных. Каждому ключу словаря
    должно соответствовать значение типа pd.Series или np.ndarray, содержащее
    набор исходных данных для соответствующего имени глобальной перменной. 
    Например, ``variable_values = {"pressure" : np.linspace(1e4, 1e6, num = 4)}``
  
  Returns
  -------
  design_cases : pd.DataFrame
    Таблица значений глобальных переменных, в которой столбцы соответствуют
    именам глобальных переменных, а количество строк соответствует количеству
    параметрических исследований, которое далее необходимо будет выполнить.
  
  Examples
  --------
  >>> import pandas as pd
  >>> import numpy as np
  >>> import repeat as rp 
  >>>
  >>> user = rp.User(token = 'уникальный токен из кабинета пользователя REPEAT')
  >>> app = rp.Application(user)
  >>> t_interval = rp.TimeInterval(start = 900, end = 1000)
  >>> project = 12345
  >>> # Создаётся набор глобальных переменных с множествами значений,
  >>> # по которым необходимо будет выполнить параметрическое исследование
  >>> # на декартовом произведении значений параметров
  >>> variable_values = dict(
  >>>     # Требуется выполнить параметрическое исследование при изменении
  >>>     # параметра hole_area модели REPEAT
  >>>     hole_area = np.linspace(1e-7, 0.031415, num = 2),
  >>>     # В примере параметрического исследования не требуется учитывать 
  >>>     # параметр pipe_diameter
  >>>     pipe_diameter = np.array([0.2]),
  >>>     pressure = np.linspace(1e4, 1e6, num = 4),
  >>>  )
  >>> model = app.get_exploration_model(project, t_interval)
  >>> # Создаётся таблица с множеством значений глобальных переменных 
  >>> input_data = rp.parametric_study.get_cartesian_product(
  >>>     model, 
  >>>     variable_values
  >>>  )
  >>> # Создаётся вектор для сохранения результатов расчёта 
  >>> result_name = "flowrate"
  >>> result = pd.Series(
  >>>     np.full_like(input_data['pressure'], np.nan),
  >>>     name = result_name
  >>>  )
  >>> # Цикл расчётов для параметрических исследований
  >>> for i, variables in input_data.iterrows():
  >>>     with model as md:
  >>>         md.run(variables)
  >>>         result.loc[i] = md.get_results(result_name).iloc[-1]
  >>> 
  >>> # Подготовка общей таблицы для параметрических исследований
  >>> design_cases = pd.concat([input_data, result], axis = 1)
  """
  vld.validate_is_exploration_model(model)
  if not isinstance(variable_values, dict):
    raise err.REPEATValidationError(
      "Используйте структуру словаря для перечисления имён глобальных переменных "
      "и соответствующих наборов значений.\nНапример, "
      "variable_values = dict(pressure = np.linspace(1e4, 1e6, num = 4))"
      )

  vld.validate_variables_names(
    input_names = set(variable_values.keys()),
    existing_names = model.existing_variables_names
    )
  vld.validate_empty_arrays(variable_values)
  design_cases = _make_cartesian_product(variable_values)
  
  return design_cases

def _make_latin_hypercube(bounds : pd.DataFrame, sample_size : int, 
                          seed : int = None, optimization : str = None, 
                          strength : int = 1):
  try:
    sampler = qmc.LatinHypercube(
      d = bounds.shape[1],
      seed = seed,
      optimization = optimization,
      strength = strength
      )
  except ValueError as e:
    err.latin_hypercube_handle_init_errors(e)
  
  try:
    sample = sampler.random(n = sample_size)
    
  except ValueError as e:
    err.latin_hypercube_handle_sampling_errors(e)
  
  design_cases = qmc.scale(
    sample, 
    l_bounds = bounds.loc["low"], 
    u_bounds = bounds.loc["up"]
    )
  design_cases = pd.DataFrame(design_cases, columns = bounds.columns)
  
  return design_cases

def get_latin_hypercube(model : rm.ExplorationModel,
                        variable_bounds : dict[str, list | float], 
                        sample_size : int, 
                        seed : int = None, 
                        optimization : str = None, 
                        strength : int = 1
                        ) -> pd.DataFrame:
  """
  Функция возвращает разреженный набор значений глобальных переменных по методу 
  **латинского гиперкуба** с целью выполнения параметрических исследований 
  модели REPEAT.
  
  Метод **латинского гиперкуба** применяется в следующих случаях:
    
  #. Модель требует значительного времени на выполнение каждого расчёта при 
     ограниченном общем времени на выполнение исследований;
  #. Высокая размерность задачи параметрических исследований, содержащая 
     большое количество варьируемых переменных, что приводит к значительным
     затратам времени на выполнение параметрических исследований.
  
  Notes
  -----
  
  Для подготовки разреженного набора значений глобальных переменных данная 
  функция использует возможности класса `LatinHypercube <https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.qmc.LatinHypercube.html#latinhypercube>`_ 
  пакета `SciPy <https://docs.scipy.org/doc/scipy/index.html>`_.
  
  Parameters
  ----------
  model : rm.ExplorationModel
    Экземпляр класса ExplorationModel.
  variable_bounds : dict[str, list | float]
    Словарь с наборами верхних и нижних границ значений глобальных переменных. 
    Ключами словаря должны быть строковые значения имён глобальных переменных.
    Каждому ключу словаря должен соответствовать список, содержащий нижнее и 
    верхнее значения границ для соответствующего имени глобальной перменной.
    Если значение глобальной переменной в рамках параметрических исследований
    не требуется учитывать (её значение должно быть постоянным), то 
    ключу словаря должно соответствовать одно вещественное значение.
    Например, ``variable_bounds = {"pressure" : [1e4, 1e6], "diameter" : 0.1}``
  sample_size : int
    Размер набора значений глобальных переменных, равный количеству 
    параметрических исследований, которое далее необходимо будет выполнить.
  seed : int, optional
    Положительное целочисленное значение для обеспечения повторяемости 
    случайного набора значений глобальных переменных. Значение по умолчанию None.
  optimization : str, optional
    Дополнительная оптимизация значений глобальных переменных для повышения
    равномерности заполнения пространства значений переменных. Значение по 
    умолчанию None. Аргумент может принимать следующие значения:
      
    - ``"random-cd"`` Случайное изменение значений переменных при существующих
      близких значениях других переменных;
    - ``"lloyd"`` Изменяет значения переменных по модифицированному алгоритму
      Lloyd-Max.
  
  strength : int, optional
    Способ заполнения пространства значений глобальных переменных. Целое число,
    принимающее значение 1 или 2. Значение по умолчанию 1. 
    
    - В случае ``strength = 1`` функция заполняет пространство значений так, 
      чтобы в наборах расчётных случаев не было повторений значений 
      глобальных переменных.
    - В случае ``strength = 2`` функция обеспечивает равномерность плотности 
      пространства значений переменных. При этом на аргумент **sample_size** 
      накладываются следующие ограничения при ``strength = 2``: sample_size 
      должно быть квадратом простого числа, ``sample_size = p**2``, 
      где p - простое число [1, 2, 3, 4]. 
      Тогда sample_size = 1, 4, 9, 16 и т.д., при этом количество варьируемых 
      глобальных переменных (содержащих верхнее и нижнее значения) в
      `variable_bounds` должно быть ``<= p + 1``.
  
  Returns
  -------
  design_cases : pd.DataFrame
    Таблица значений глобальных переменных, в которой столбцы соответствуют
    именам глобальных переменных, а количество строк, равное `sample_size`,
    соответствует количеству параметрических исследований, которое далее 
    необходимо будет выполнить.

  Examples
  --------
  >>> import pandas as pd
  >>> import numpy as np
  >>> import repeat as rp 
  >>>
  >>> user = rp.User(token = 'уникальный токен из кабинета пользователя REPEAT')
  >>> app = rp.Application(user)
  >>> t_interval = rp.TimeInterval(start = 900, end = 1000)
  >>> project = 12345
  >>> # Создаётся набор глобальных переменных с нижними и верхними значениями,
  >>> # по которым необходимо будет выполнить параметрическое исследование
  >>> # на пространстве значений переменных, полученного по методу 
  >>> # латинского гиперкуба
  >>> variable_values = dict(
  >>>     # Требуется выполнить параметрическое исследование при изменении
  >>>     # параметра hole_area модели REPEAT
  >>>     hole_area = [1e-7, 0.031415],
  >>>     # В примере параметрического исследования не требуется учитывать 
  >>>     # параметр pipe_diameter
  >>>     pipe_diameter = 0.2,
  >>>     pressure = [1e4, 1e6],
  >>>  )
  >>> model = app.get_exploration_model(project, t_interval)
  >>> # Создаётся пространство значений переменных по методу
  >>> # латинского гиперкуба
  >>> input_data = rp.parametric_study.get_latin_hypercube(
  >>>     model, 
  >>>     variable_values,
  >>>     seed = 5, # Обеспечивается повторяемость случайного набора значений
  >>>     sample_size = 9, # Требуется 9 расчётных случаев
  >>>     # Обеспечивается равномерность заполнения пространства значений 
  >>>     strength = 2,
  >>>     optimization = "random-cd"
  >>>  )
  >>> # Создаётся вектор для сохранения результатов расчёта 
  >>> result_name = "flowrate"
  >>> result = pd.Series(
  >>>     np.full_like(input_data['pressure'], np.nan),
  >>>     name = result_name
  >>>  )
  >>> # Цикл расчётов для параметрических исследований
  >>> for i, variables in input_data.iterrows():
  >>>     with model as md:
  >>>         md.run(variables)
  >>>         result.loc[i] = md.get_results(result_name).iloc[-1]
  >>> 
  >>> # Подготовка общей таблицы для параметрических исследований
  >>> design_cases = pd.concat([input_data, result], axis = 1)
  """
  
  vld.validate_is_exploration_model(model)
  if not isinstance(variable_bounds, dict):
    raise err.REPEATValidationError(
      "Используйте структуру словаря для перечисления имён глобальных переменных "
      "и соответствующих верхних и нижних значений границ переменных.\nНапример, "
      "variable_values = dict(pressure = [1e4, 1e6], diameter = 0.1)"
      )
  
  vld.validate_variables_names(
    input_names = set(variable_bounds.keys()),
    existing_names = model.existing_variables_names
    )
  bounds, constants = vld.validate_and_prepare_bounds(variable_bounds)
  design_cases = _make_latin_hypercube(bounds, sample_size, seed, optimization, 
                                       strength)
  for name, value in constants.items():
    design_cases[name] = value
  
  return design_cases
  
  

