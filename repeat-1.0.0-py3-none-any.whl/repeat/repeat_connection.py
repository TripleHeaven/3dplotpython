#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from requests.auth import AuthBase


class APIKeyAuth(AuthBase):
  """
  API-Key aвторизация для запросов модулем requests
  
  Parameters
  ----------
  token : str
    Токен для авторизации запросов к ядру и расчётному модулю REPEAT.

  Returns
  -------
  None

  Examples
  --------
  >>> response = requests.get(url, auth = APIKeyAuth(token))  

  """
  def __init__(self, token : str):
    self.token = token

  def __call__(self, request):
    request.headers["Api-Key"] = f"Api-Key {self.token}"
    return request



