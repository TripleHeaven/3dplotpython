#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Основные структуры данных для обеспечения работы модуля repeat
"""
import pandas as pd
from pydantic.dataclasses import dataclass
from pydantic import validator

@dataclass(frozen = True)
class TimeInterval:
  """
  Класс для описания интервала времени, которое потребуется для настройки 
  параметров с целью получения их значений от модели REPEAT.

  Notes
  -----
  Настройка параметров производится с помощью класса Parameter

  Parameters
  ----------
  start : int
    Начальный момент интервала времени в миллисекундах [мс]
  end : int
    Конечный момент интервала времени в [мс]
 
  Returns
  -------
  None
  
  Examples
  --------
  >>> from repeat import TimeInterval
  >>>   
  >>> t_interval = TimeInterval(start = 2000, end = 2050)
  >>> print(t_interval)
  >>> # TimeInterval(start = 2000, end = 2050)
  """
  start : int
  end : int

  def to_repeat(self):
    return {
      'timeStart': self.start,
      'timeEnd': self.end
      }
  
  @validator('start')
  def check_start_negative(cls, start):
    if start < 0:
      raise ValueError(
        "Значение начального момента времени start должно быть больше нуля "
        "или равно нулю.\n"
        )
    return start

  @validator('end')
  def check_start_after_end(cls, end, values):
    if 'start' in values and end <= values['start']:
      raise ValueError(
        "Значение конечного момента времени end должно быть больше "
        "начального момента времени start\n"
        )
    return end

@dataclass(frozen = True)
class Parameter:
  """
  Класс для описания параметра, о котором необходимо получить информацию из
  модели REPEAT

  Parameters
  ----------
  name : str
    Имя параметра. Список имён модели REPEAT можно получить из атрибута 
    parameters экземпляра класса Model
  time_interval : TimeInterval
    Интервал времени, для которого необходимо получить значения параметра. 
    Интервал времени настраивается в результате создания экземпляра класса
    TimeInterval
 
  Returns
  -------
  None
  
  Examples
  --------
  >>> from repeat import TimeInterval, Parameter
  >>>  
  >>> t_interval = TimeInterval(start = 2000, end = 2050)
  >>> param = Parameter(name = "1687722637724_OUT_3", time_interval = t_interval)
  >>> print(param)
  >>> # Parameter(name = '1687722637724_OUT_3',
  >>> #           time_interval = TimeInterval(start = 2000, end = 2050))
  """
  name : str
  time_interval : TimeInterval

  @validator('name')
  def check_emty_name(cls, name):
    if not name:
      raise ValueError(
        "Имя параметра name не должно быть пустым\n"
        )
    return name      
  
  def to_repeat(self):
    return {'varName' : self.name} | self.time_interval.to_repeat()

def prepare_results(parameter : Parameter, data : dict) -> pd.Series:
  """
  Вспомогательная функция преобразования результатов из списков в словаре
  в структуру pandas.Series
  """
  return pd.Series(
    data = data['dataValues'],
    index = data['dataTimes'],
    name = parameter.name
    )

 
  
