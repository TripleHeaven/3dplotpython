#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Модуль для описания валидации объектов, связанных с функционированием модуля 
REPEAT:
  
  - Валидация ввода пользователем значений аргументов функций и методов 
  - Валидация объектов, полученных от платформы REPEAT в пакет repeat
"""
import pandas as pd
import requests
import repeat.errors  as err
import repeat.repeat_model as rm
import repeat.repeat_user as ru
import repeat.messages as rmsg


def _get_message_allowed_custom_named_results(custom_named_result_ids : dict):
  """
  Функция возвращает сообщение с перечнем допустимых параметров результатов,
  содержащих пользовательские названия

  Parameters
  ----------
  custom_named_result_ids : dict
   Словарь, в котором ключами являются пользовательские названия параметров, 
   ранее присвоенные пользователем в модели REPEAT, например, блокам out. 

  Returns
  -------
  message : str
    Сообщение с перечнем допустимых. Возвращается пустая строка в случае 
    отсутствия в модели REPEAT параметров результатов, содержащих 
    пользовательские названия

  """
  message = ""
  if custom_named_result_ids:
    message = (
      "Ваша модель допускает использование следующих параметров результатов, "
      "содержащих пользовательские названия:" +
      rmsg.create_unordered_list_message(custom_named_result_ids.keys())
      )
  
  return message

def _validate_int(value : str, name : str, 
                  msg_allowed_custom_named_results : str):
  try:
   int(value)
  
  except ValueError:
    raise err.REPEATValidationError(
      f"Неприемлемая часть {value} в имени параметра {name}.\n"
      "Проверьте, пожалуйста, имя параметра.\n"
      f"{msg_allowed_custom_named_results}"
      )

def validate_parameter_name_structure(name : str, 
                                      custom_named_result_ids : dict = None):
  """
  Функция проверяет состав имени параметра REPEAT на содержание следующих
  обязательных компонентов:
  
    - Целочисленная приставка, например, 1719210666632
    - Корень, содержащий только значение OUT или IN
    - Целочисленный суффикс, например, 2
  
  Все компоненты должны быть разделены нижним подчёркиванием _. Пример имени
  параметра, который пройдёт процесс валидации '1719210666632_OUT_3'

  Parameters
  ----------
  name : str
    Имя параметра REPEAT.
  custom_named_result_ids : dict
   Словарь, в котором ключами являются пользовательские названия параметров, 
   ранее присвоенные пользователем в модели REPEAT, например, блокам out.
   По умолчанию None.

  Raises
  ------
  REPEATValidationError
    Ошибка объявляемая в случае несоответствия имени параметра наличию 
    обязательных компонентов.

  Returns
  -------
  None.

  """
  msg_allowed_custom_named_results = _get_message_allowed_custom_named_results(
    custom_named_result_ids
    )
  match name.split('_'):
    case prefix, 'OUT' | 'IN', suffix:
      _validate_int(prefix, name, msg_allowed_custom_named_results)
      _validate_int(suffix, name, msg_allowed_custom_named_results)
      
    case _:
      raise err.REPEATValidationError(
        f"Неприемлемое имя параметра {name}.\n"
        "Проверьте, пожалуйста, имя параметра, которое обязательно должно "
        "содержать следующие обязательные компоненты:\n"
        "  - Целочисленная приставка, например, 1719210666632,\n"
        "  - Корень, содержащий только значение OUT или IN,\n"
        "  - Целочисленный суффикс, например, 2.\n"
        "Все компоненты должны быть разделены нижним подчёркиванием _.\n"
        "Пример корректного имени параметра '1719210666632_OUT_2'\n"
        f"{msg_allowed_custom_named_results}"
        )
    
def validate_variables_names(input_names : set[str], existing_names : set[str]):
  """
  Проверка строковых значений имён переменных у объектов, созданных в Python, 
  на соответствие именам существующих глобальных переменных модели REPEAT.
  Для успешного прохождения проверки требуется полное соответствие проверяемого 
  множества input_names существующим глобальным переменным модели REPEAT.

  Parameters
  ----------
  input_names : set[str]
    Множество строковых значений имён переменных.
  existing_names : set[str]
    Множество существующих глобальных переменных модели REPEAT.

  Raises
  ------
  REPEATValidationError
    Ошибка проверки, объявляемая в случае отличия множества input_names от
    множества existing_names.

  Returns
  -------
  None.

  """
  # Лишние переменные в наборе новых переменных
  unwanted = input_names - existing_names
  if unwanted:
    description_unwanted = rmsg.create_unordered_list_message(unwanted)
    valid_variables = rmsg.create_unordered_list_message(existing_names)
    raise err.REPEATVariableNameError(
      "В наборе переменных пользователя присутствуют переменные, которые "
      "заранее не были созданы в модели REPEAT.\n"
      "Требуется удалить из набора следующие переменные:"
      f"{description_unwanted}\n"
      "Допустимые к использованию глобальные переменные модели REPEAT:"
      f"{valid_variables}"
      )
  # В наборе новых переменных пропущена часть существующих в модели REPEAT
  forget = existing_names - input_names
  if forget:
    description_forget = rmsg.create_unordered_list_message(forget)
    valid_variables = rmsg.create_unordered_list_message(existing_names)
    raise err.REPEATVariableNameError(
      "В наборе переменных пользователя отсутствуют переменные, которые "
      "существуют в модели REPEAT.\n"
      "Требуется добавить в набор следующие переменные:"
      f"{description_forget}\n"
      "Допустимые к использованию глобальные переменные модели REPEAT:"
      f"{valid_variables}"
      )

def _is_float(value : str):
  try:
    float(value)
    return True
  
  except ValueError:
    return False

def validate_variables_empty_names(variables : dict[str, str], 
                                   project_name, project_id):
  
  if "" in variables.keys():
    raise err.REPEATVariableNameError(
      f"В модели {project_name} проекта с идентификатором {project_id} "
      "в таблице переменных присутствуют глобальные переменные, "
      f"в которых отсутствуют имена переменных.\n"
      "Пожалуйста, присвойте имена глобальным переменным вашей модели "
      "с помощью инструмента Переменные в приложении REPEAT."
      )

def validate_variables_float_values(variables : dict[str, str], 
                                    project_name, project_id):
  error_values = [name for name, val in variables.items() if not _is_float(val)]
  if error_values:
    raise err.REPEATVariableValueError(
      f"В модели {project_name} проекта с идентификатором {project_id} "
      "следующие глобальные переменные не содержат вещественных значений:\n" +
      rmsg.create_unordered_list_message(error_values) + "\n" +
      "Добавьте вещественные значения глобальным переменным вашей модели "
      "с помощью инструмента Переменные в приложении REPEAT."
      )

def validate_empty_arrays(variables : dict[str, pd.Series]):
  empties = [name for name, array in variables.items() if array.size == 0]
  if empties:
    raise err.REPEATVariableValueError(
      "Наборы значений глобальных перменных не должны быть пустыми.\n"
      "Следующие векторы глобальных перменных не содержат вещественных значений:\n" +
      rmsg.create_unordered_list_message(empties)
      )

def validate_and_prepare_bounds(variable_bounds:dict[str, list | float]
                                ) -> pd.DataFrame:
  validated = {}
  constants = {}
  for name, values in variable_bounds.items():
    match values:
      case float(constant):
        constants[name] = constant
        
      case [float(first), float(second)] if first == second:
        constants[name] = first
        
      case [float(first), float(second)]:
        validated[name] = pd.Series(
          sorted([first, second]),
          index = ["low", "up"]
          )
      case _:
        raise err.REPEATVariableValueError(
          "Пожалуйста, проверьте значения у глобальной переменной "
          f"с именем {name}.\n"
          "Допускаются следующие форматы задания исходных данных:\n"
          "  - В списке может быть верхнее и нижнее вещественные значения "
          "переменной;\n"
          "  - Имени глобальной переменной может соответствовать одно "
          "постоянное вещественное значение.\n"
          "Текущее значение, содержащее ошибки, следующее:\n"
          f"{name} : {values}"
          )

  bounds = pd.DataFrame(validated)
  
  return bounds, constants


def validate_is_pandas_table(input_data: pd.DataFrame):
  if not isinstance(input_data, pd.DataFrame):
    raise err.REPEATValidationError(
      "Таблица исходных данных для подготовки новых значений в глобальные "
      "переменные REPEAT должа быть типа pandas.DataFrame"
      )

def validate_is_exploration_model(model: rm.ExplorationModel):
  if not isinstance(model, rm.ExplorationModel):
    raise err.REPEATValidationError(
      "Объект модели для взаимодействия с платформой REPEAT должен быть "
      "экземпляром класса ExplorationModel"
      )

def validate_user_api_key(endpoints : ru._UserEndpoints):
  """
  Функция проверяет API ключ пользователя для обеспечения допуска к платформе
  REPEAT

  Parameters
  ----------
  endpoints : _UserEndpoints
    Вспомогательный класс аттрибутов с адресами web REST API для взаимодействия 
    с кабинетом пользователя.

  Raises
  ------
  REPEATAPIKeyError
    Ошибка объявляется при следующих проблемах API ключа: 
      1. ключ неверно скопирован; 2. завершился срок действия ключа.
  REPEATUnknownError
    Незвестная ошибка при проверке API ключа пользователя выводом существующей
    информации из атрибута response.text модуля requests.

  Returns
  -------
  None.

  """
  response = requests.get(
    endpoints.api_key_validation,
    auth = endpoints.auth
    )
  if response.status_code != requests.codes.ok:
    error = response.json()
    desription = error['errors'][0]
    match desription:
      case {'code' : 1250, 'message': 'The Api-Key is expired.'}:
        raise err.REPEATAPIKeyError(
          "Завершился срок действия API ключа.\n"
          "Для взаимодействия с платформой REPEAT необходимо использовать "
          "новый ключ из вашего личного кабинета"
          )
      case {'code' : 1121, 'message': 'Invalid ApiKey.'}:
        raise err.REPEATAPIKeyError(
          "Некорректный API ключ.\n"
          "Повторно скопируйте API ключ из вашего личного кабинета в "
          "вашу Python программу в место создания экземпляра класса User"
          )
      case _:
        raise err.REPEATUnknownError(
          "Возникла незвестная ошибка при проверке API ключа пользователя.\n"
          "Обратитесь, пожалуйста, в службу технической поддержки.\n"
          "Информация для специалистов технической поддержки:\n"
          f"Ответ платформы REPEAT при валидации:\n {response.text}"
          )
