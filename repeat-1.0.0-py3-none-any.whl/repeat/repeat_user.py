#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Модуль для настройки свойств пользователя REPEAT
"""
import re
from dataclasses import dataclass
from pydantic.dataclasses import dataclass as pydantic_dataclass
from pydantic import validator
from repeat.repeat_connection import APIKeyAuth
import repeat.errors as err

@pydantic_dataclass(frozen = True)
class User:
  """
  Класс с описанием параметров пользователя, необходимых для авторизации
  и последующего использования модуля repeat
  
  Parameters
  ----------
  token : str
    API ключ для авторизации запросов к ядру и расчётному модулю REPEAT.
    API ключ можно создать и скопировать в вашем личном кабинете
    по адресу https://app.repeatlab.ru/account/api-keys

  Returns
  -------
  None

  Examples
  --------
  >>> from repeat import User 
  >>> 
  >>> user = User(token = 'my_api_key_value_from_app.repeatlab.ru')
  """
  token : str
  
  @validator('token')
  def check_emty_name(cls, token):
    if not token:
      raise err.REPEATAPIKeyError(
        "Введите значение API ключа\nЗначение API ключа не должно быть пустым\n"
        )
    return token
  
  @validator('token')
  def check_non_latin_chars(cls, token):
    """
    API ключ может содержать только следующие символы:
       - Латинские буквы,
       - Цифры,
       - Точки и нижние подчёркивания.
    
    Все остальные символы являеются некорректными для API ключа.
    """
    if (invalid_symbols:= re.findall('[^a-zA-Z0-9._-]', token)):
      invalid_symbol_msg = ', '.join(invalid_symbols)
      raise err.REPEATAPIKeyError(
        "API ключ содержит следующие некорректные символы:\n"
        f"{invalid_symbol_msg}\n"
        "Повторно скопируйте API ключ из вашего личного кабинета в "
        "вашу Python программу в место создания экземпляра класса User"
        )
    return token

@dataclass
class _UserEndpoints:
  """
  Вспомогательный класс аттрибутов с адресами web REST API для взаимодействия 
  с кабинетом пользователя
  
  Parameters
  ----------
  address : str
    Адрес сайта программы REPEAT. Подробное описание смотри в справке класса
    Application.
  auth : APIKeyAuth
    Экземпляр класса APIKeyAuth для aвторизации во время запросов модулем 
    requests.

  Attributes
  ----------
  api_key_validation : str
    address + /backend/api/v1/public/apiKey 
    Метод GET для проверки API ключа на стороне сервера.

  Returns
  -------
  None  
  """

  address : str
  auth : APIKeyAuth
  
  def __post_init__(self):
    # адрес web api get для проверки API ключа
    self.api_key_validation = (self.address +
       '/backend/api/v1/public/apiKey')

