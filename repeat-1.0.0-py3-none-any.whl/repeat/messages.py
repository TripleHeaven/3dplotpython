#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Вспомогательный модуль имён, сообщений и форматов вывода
"""
from enum import StrEnum

class REPEAT_MODULE_NAMES(StrEnum):
  base = "База"
  codegenerating = "Кодогенерация"
  electrodynamics = "Электродинамика"
  hydro = "Изотермическая гидравлика"
  heathydro = "Теплогидравлика и Теплообмен"
  mechanics = "Механика"
  pneumo = "Пневматические системы"
  

class FMT(StrEnum):
  UNORDERED_LIST = ",\n  - "
  
def create_unordered_list_message(items : list[str]) -> str:
  unordered_list = (
    FMT.UNORDERED_LIST[1:] +
    FMT.UNORDERED_LIST.join(items) 
    )
  return unordered_list