#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Исключения, возможные при взаимодействии с модулем
"""
from requests.exceptions import HTTPError
import repeat.data_structures as ds
import repeat.messages as rmsg


class REPEATError(Exception):
  """Общее исключение, не попадающее под частные случаи, перечисленные в модуле.
  От данного класса допускается наследие для частных случаев классов-исключений.
  """

class REPEATModuleInitError(OSError):
  "Ошибка, объявляемая при проблеме инициализации модуля repeat"
  
class REPEATHTTPError(IOError):
  "Исключение, объявляемое при проблеме интернет соединения c REPEAT"

class REPEATModelBusy(REPEATHTTPError):
  "Ошибка занятой модели расчётным модулем, когда повторно нельзя запустить расчёт"

class REPEATProjectNotExistError(REPEATError):
  """Ошибка, объявляемая если пользователь не создал ни одного проекта или
  в случае отсутствия проекта в списке существующих проектов платформы REPEAT
  """

class REPEATModelError(REPEATHTTPError):
  "Исключение для модели, содержащей ошибки в реализации схемы"

class REPEATSolverNotRunError(REPEATHTTPError):
  "Ошибка, объявляемая при проблеме взаимодействия с ядром REPEAT"

class REPEATSolverError(REPEATHTTPError):
  "Ошибка, объявляемая при проблеме расчёта модели REPEAT"

class REPEATSolverInitError(REPEATSolverError):
  "Ошибка, объявляемая при проблеме запуска на расчёт модели REPEAT"

class REPEATParameterNotExistError(REPEATHTTPError):
  "Исключение, объявляемое при проблеме с параметром модели REPEAT"

class REPEATResultsNotExistError(REPEATSolverNotRunError):
  """Ошибка отсутствия результатов расчёта.
  Ошибка объявляется, если расчёт не завершён или не запускался"""

class REPEATValidationError(ValueError):
  """Ошибка объявляется при вводе пользователем некорректных значений
  аргументов функций и методов.
  """

class REPEATValidationLatinHypercubeError(ValueError):
  """Ошибка объявляется при вводе пользователем некорректных значений
  аргументов функций при подготовке значений глобальных переменных методом
  латинского гиперкуба.
  """

class REPEATVariableNotExistError(ValueError):
  """Исключение, объявляемое при отсутствии глобальных переменных в модели 
  REPEAT. Через глобальные переменные выполняется обмен значениями между моделью
  и пакетом Python.
  """

class REPEATVariableNameError(ValueError):
  """Ошибка в случае несоответствия имён глобальных переменных модели именам
  переменных, используемых для обмена значениями между Python программой и 
  моделью REPEAT
  """
  # В данном классе уместнее наследоваться от KeyError, но
  # наследование от KeyError приводит к проблеме с выводом в консоль сообщений
  # ошибок, содержащих перевод на новую строку (\n)

class REPEATVariableValueError(ValueError):
  """Ошибка в случае некорректных значений глобальных переменных модели
  """

class REPEATAPIKeyError(REPEATValidationError):
  """Исключение, объявляемое в случаях проблем при проверке API ключа 
  пользователя. Ошибочный ключ может быть некорректным, устаревшим или пустым.
  """

class REPEATTariffPermissionError(REPEATError):
  """
  Ошибка, объявляемая при отсутсвии прав у пользователя на использование одгого
  или нескольких модулей платформы REPEAT
  """

class REPEATUnknownError(REPEATError):
  "Неизвестная ошибка при выполнении кода пакета repeat"

def handle_unknown_errors(error : HTTPError, 
                          execution_stage_message : str = None,
                          backend_message : str = None
                          ):
  msg = ''
  if execution_stage_message is not None:
    msg = f'{execution_stage_message}\n'
  
  msg_extend = ''
  if backend_message is not None:
    msg_extend = f'{backend_message}\n'
  
  raise REPEATHTTPError(
    f"Неизвестная ошибка взаимодействия с REPEAT\n{msg}"
    f"Обратитесь, пожалуйста, в службу технической поддержки\n"
    f"{error}\n"
    f"{msg_extend}"
    )

def handle_user_error_codes(error : HTTPError):
  status = error.response.status_code
  match status:
    case 400:
      raise REPEATSolverNotRunError(
        "Не запущен расчёт модели.\n"
        "Для исправления ошибки выполните следующие действия:\n"
        "  - В интерфейсе модели запустите расчёт (RUN)\n"
        "  - затем поставьте расчёт на пузу (FREEZE)\n"
        f"{error}"
        )
    case 404 | 500 | 502:
      raise REPEATHTTPError(
          f"Ошибка взаимодействия с REPEAT\n"
          f"на этапе подключения к ядру REPEAT\n"
          f"Обратитесь, пожалуйста, в службу технической поддержки\n"
          f"{error}"
          )      
    case _:
      handle_unknown_errors(error, 'на этапе подключения к ядру REPEAT')

def handle_solver_error_codes(error : HTTPError, parameter : ds.Parameter):
  status = error.response.status_code
  match status:
    case 406:
      raise REPEATParameterNotExistError(
        f"Ещё не выполнен расчёт значений параметра {parameter.name}\n"
        f"для заданного интервала времени {parameter.time_interval}"
        )
    case 410:
      raise REPEATSolverNotRunError(
        "Не запущен расчёт модели. Или потеряно соединение с расчётным модулем\n"
        "Для исправления ошибки выполните следующие действия:\n"
        "  - В интерфейсе модели принудительно остановите расчёт (STOP)"
        "  - Запустите расчёт (RUN)\n"
        "  - затем поставьте расчёт на пузу (FREEZE)\n"
        f"{error}"
        )
    case _:
      handle_unknown_errors(error, 
                            'на этапе подключения к расчётному модулю REPEAT')

def handle_model_info_error_codes(error : HTTPError):
  status = error.response.status_code
  match status:
    case 100 | 101:
      raise REPEATSolverError(
        "Остановлен расчёт модели REPEAT\n"
        "Подробное описание причин остановки расчёта приведено в журнале REPEAT"
        )
    case _:
      handle_unknown_errors(error, 'на этапе запроса параметров модели')

def handle_model_status_errors(error : HTTPError):
  "Обрабатывает ошибки, полученные методом status класса ExplorationModel"
  status = error.response.status_code
  match status:
    case 410:
      raise REPEATSolverNotRunError(
        "Не запущен расчёт модели. Или потеряно соединение с расчётным модулем.\n"
        "Требуется запустить расчёт модели с помощью метода .run() в экземпляре "
        "класса ExplorationModel"
        )
    case _:
      handle_unknown_errors(
        error,
        "на этапе получения информации о состоянии модели"
        )

def handle_initialize_solver_errors(error : HTTPError):
  """
  Обрабатывает ошибки, полученные методом _initialize_solver() класса
  ExplorationModel на этапе попытки запуска модели на расчёт методом .run()
  """
  status = error.response.status_code
  match status:
    case 400:
      raise REPEATModelError(
        "Модель содержит ошибки в реализации схемы или настроек блоков.\n"
        "Проверьте вашу модель в приложении REPEAT"
        )
      
    case 403:
      errors_data = error.response.json()
      error_desription = errors_data['errors'][0]
      modules_access_denied = error_desription['context']['deniedAccess']
      module_names = []
      for module in modules_access_denied:
        module_names.append(f'{rmsg.REPEAT_MODULE_NAMES[module]}')
      
      raise REPEATTariffPermissionError(
        "Отсутствуют права на использование следующих модулей " +
        "платформы REPEAT:" + 
        rmsg.create_unordered_list_message(module_names) + 
        "\nОбратитесь в службу технической поддержки для активации модулей"
        )
      
    case 423:
      raise REPEATModelBusy(
        "Модель уже в процессе расчёта.\n"
        "Остановите ранее запущенный расчёт и повторите запуск вашей программы"
        )
    case 504:
      raise REPEATSolverInitError(
        "Сетевые проблемы при запуске модели на расчёт.\n"
        "Попробуйте перезапустить расчёт методом .run()"
        )
      
    case 510:
      raise REPEATSolverInitError(
        "Заняты все расчётные модули.\n"
        "Необходимо освободить расчётный модуль для вашей модели."
        )
    
    case _:
      backend_msg = error.response.text
      handle_unknown_errors(
        error, 
        'на этапе инициализации процесса расчёта модели REPEAT',
        backend_msg
        )  
  
def latin_hypercube_handle_init_errors(error : ValueError):
  """
  Обрабатывает ошибки, полученные функцией _make_latin_hypercube() модуля
  parametric_study на этапе инициализации экземпляра класса LatinHypercube
  """
  message = error.args[0]
  if "d must be a non-negative integer value" in message:
    raise REPEATValidationLatinHypercubeError(
      "Количество глобальных переменных с варьируемыми значениями "
      "должно быть больше нуля"
    ) from error
    
  elif "is not a valid optimization method" in message:
    raise REPEATValidationLatinHypercubeError(
      "Ошибка при введении наименования алгоритма оптимизации."
      "Введите один из следующих алгоритмов: 'random-cd', 'lloyd' или None" 
    ) from error
  
  elif "is not a valid strength" in message:
    raise REPEATValidationLatinHypercubeError(
      "Неверное значение аргумента strength.\n"
      "Аргумент strength может принимать значение 1 или 2."
      ) from error
  
  else: 
    raise error

def latin_hypercube_handle_sampling_errors(error : ValueError):
  """
  Обрабатывает ошибки, полученные функцией _make_latin_hypercube() модуля
  parametric_study на этапе вызова метода random() 
  экземпляра класса LatinHypercube
  """
  message = error.args[0]
  if "n is not the square of a prime number" in message:
    variants = message.partition("[")
    raise REPEATValidationLatinHypercubeError(
      "Значение sample_size не является квадратом простого числа."
      "Необходимо выбрать другое значение sample_size.\n"
      "Например, " + variants[1] + variants[2]
    ) from error
    
  elif "n is too small for d. Must be n > (d-1)**2" in message:
    raise REPEATValidationLatinHypercubeError(
      "Слишком маленькое значение sample_size для указанного количества "
      "глобальных переменных с варьируемыми значениями"
      ) from error
    
  else: 
    raise error
  
  
    
